import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Play } from "lucide-react"
import { StarRating } from "@/components/star-rating"

export default function TopRated() {
  const recommendations = [
    { title: "Neon Dreams", artist: "Synthwave Masters", cover: "/placeholder.svg?height=150&width=150", rating: 5 },
    { title: "Ocean Breeze", artist: "Coastal Sounds", cover: "/placeholder.svg?height=150&width=150", rating: 5 },
    { title: "Mountain Echo", artist: "Alpine Collective", cover: "/placeholder.svg?height=150&width=150", rating: 4 },
    { title: "Urban Jungle", artist: "City Beats", cover: "/placeholder.svg?height=150&width=150", rating: 4 },
    { title: "Midnight Drive", artist: "Night Owls", cover: "/placeholder.svg?height=150&width=150", rating: 4 },
    { title: "Summer Vibes", artist: "Beach Collective", cover: "/placeholder.svg?height=150&width=150", rating: 4 },
  ]

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
      {recommendations.map((item, index) => (
        <Card key={index} className="group relative overflow-hidden bg-card hover:bg-card/80 transition-colors">
          <CardContent className="p-4">
            <div className="relative aspect-square mb-3 rounded-md overflow-hidden">
              <Image src={item.cover || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                  <Play className="h-5 w-5 text-white ml-0.5" />
                </div>
              </div>
            </div>
            <h3 className="font-medium text-sm line-clamp-1">{item.title}</h3>
            <p className="text-xs text-muted-foreground line-clamp-1 mb-1">{item.artist}</p>
            <StarRating rating={item.rating} onRatingChange={() => {}} size={14} readOnly />
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
