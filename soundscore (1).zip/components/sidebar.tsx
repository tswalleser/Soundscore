"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"
import {
  Home,
  Search,
  Library,
  PlusCircle,
  Heart,
  BarChart,
  Clock,
  Music,
  ListMusic,
  Radio,
  User,
  Settings,
  ChevronLeft,
  ChevronRight,
  Upload,
  LogIn,
} from "lucide-react"
import { supabase } from "@/lib/supabase"
import { useSession } from "next-auth/react"
import type { Playlist } from "@/lib/types"

interface NavItem {
  title: string
  href: string
  icon: React.ReactNode
  requiresAuth?: boolean
}

export default function Sidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)
  const { data: session, status } = useSession()
  const [userPlaylists, setUserPlaylists] = useState<Playlist[]>([])

  const mainNav: NavItem[] = [
    {
      title: "Home",
      href: "/",
      icon: <Home className="h-5 w-5" />,
    },
    {
      title: "Search",
      href: "/search",
      icon: <Search className="h-5 w-5" />,
    },
    {
      title: "Your Library",
      href: "/library",
      icon: <Library className="h-5 w-5" />,
    },
  ]

  const yourMusic: NavItem[] = [
    {
      title: "Upload Music",
      href: "/upload",
      icon: <Upload className="h-5 w-5" />,
      requiresAuth: true,
    },
    {
      title: "Create Playlist",
      href: "/create-playlist",
      icon: <PlusCircle className="h-5 w-5" />,
      requiresAuth: true,
    },
    {
      title: "Liked Songs",
      href: "/liked-songs",
      icon: <Heart className="h-5 w-5" />,
      requiresAuth: true,
    },
    {
      title: "Top Rated",
      href: "/top-rated",
      icon: <BarChart className="h-5 w-5" />,
    },
    {
      title: "Recently Played",
      href: "/recently-played",
      icon: <Clock className="h-5 w-5" />,
      requiresAuth: true,
    },
  ]

  const defaultPlaylists: NavItem[] = [
    {
      title: "Discover Weekly",
      href: "/playlist/discover-weekly",
      icon: <Music className="h-5 w-5" />,
    },
    {
      title: "Release Radar",
      href: "/playlist/release-radar",
      icon: <Radio className="h-5 w-5" />,
    },
    {
      title: "Your Top Songs",
      href: "/playlist/top-songs",
      icon: <ListMusic className="h-5 w-5" />,
      requiresAuth: true,
    },
  ]

  const otherLinks: NavItem[] = session
    ? [
        {
          title: "Profile",
          href: "/profile",
          icon: <User className="h-5 w-5" />,
          requiresAuth: true,
        },
        {
          title: "Settings",
          href: "/settings",
          icon: <Settings className="h-5 w-5" />,
          requiresAuth: true,
        },
      ]
    : [
        {
          title: "Login",
          href: "/login",
          icon: <LogIn className="h-5 w-5" />,
        },
      ]

  useEffect(() => {
    const fetchUserPlaylists = async () => {
      if (status !== "authenticated" || !session?.user?.id) return

      try {
        const { data, error } = await supabase
          .from("playlists")
          .select("*")
          .eq("user_id", session.user.id)
          .order("created_at", { ascending: false })

        if (error) throw error
        setUserPlaylists(data || [])
      } catch (error) {
        console.error("Error fetching user playlists:", error)
      }
    }

    fetchUserPlaylists()
  }, [session, status])

  // Filter items based on authentication status
  const filteredYourMusic = yourMusic.filter(
    (item) => !item.requiresAuth || (item.requiresAuth && status === "authenticated"),
  )

  const filteredDefaultPlaylists = defaultPlaylists.filter(
    (item) => !item.requiresAuth || (item.requiresAuth && status === "authenticated"),
  )

  return (
    <div
      className={cn(
        "flex flex-col h-full bg-card border-r transition-all duration-300",
        collapsed ? "w-[72px]" : "w-[240px]",
      )}
    >
      <div className="flex items-center p-4">
        {!collapsed && (
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-white font-bold">S</span>
            </div>
            <span className="font-bold text-lg">SoundScore</span>
          </Link>
        )}
        {collapsed && (
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center mx-auto">
            <span className="text-white font-bold">S</span>
          </div>
        )}
        <Button variant="ghost" size="icon" className="ml-auto" onClick={() => setCollapsed(!collapsed)}>
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      <ScrollArea className="flex-1">
        <div className="px-3 py-2">
          <div className="mb-4">
            {mainNav.map((item) => (
              <Button
                key={item.href}
                variant="ghost"
                asChild
                className={cn(
                  "w-full justify-start mb-1",
                  pathname === item.href && "bg-muted",
                  collapsed && "justify-center px-2",
                )}
              >
                <Link href={item.href}>
                  {item.icon}
                  {!collapsed && <span className="ml-2">{item.title}</span>}
                </Link>
              </Button>
            ))}
          </div>

          {!collapsed && <div className="text-xs font-medium text-muted-foreground mb-2 px-4">YOUR MUSIC</div>}
          <div className="mb-4">
            {filteredYourMusic.map((item) => (
              <Button
                key={item.href}
                variant="ghost"
                asChild
                className={cn(
                  "w-full justify-start mb-1",
                  pathname === item.href && "bg-muted",
                  collapsed && "justify-center px-2",
                )}
              >
                <Link
                  href={item.requiresAuth && status !== "authenticated" ? "/login?callbackUrl=" + item.href : item.href}
                >
                  {item.icon}
                  {!collapsed && <span className="ml-2">{item.title}</span>}
                </Link>
              </Button>
            ))}
          </div>

          {!collapsed && <div className="text-xs font-medium text-muted-foreground mb-2 px-4">PLAYLISTS</div>}
          <div className="mb-4">
            {filteredDefaultPlaylists.map((item) => (
              <Button
                key={item.href}
                variant="ghost"
                asChild
                className={cn(
                  "w-full justify-start mb-1",
                  pathname === item.href && "bg-muted",
                  collapsed && "justify-center px-2",
                )}
              >
                <Link
                  href={item.requiresAuth && status !== "authenticated" ? "/login?callbackUrl=" + item.href : item.href}
                >
                  {item.icon}
                  {!collapsed && <span className="ml-2">{item.title}</span>}
                </Link>
              </Button>
            ))}

            {!collapsed && status === "authenticated" && userPlaylists.length > 0 && (
              <>
                <div className="h-px bg-muted my-2" />
                {userPlaylists.map((playlist) => (
                  <Button
                    key={playlist.id}
                    variant="ghost"
                    asChild
                    className={cn("w-full justify-start mb-1", pathname === `/playlist/${playlist.id}` && "bg-muted")}
                  >
                    <Link href={`/playlist/${playlist.id}`}>
                      <ListMusic className="h-5 w-5" />
                      <span className="ml-2 truncate">{playlist.name}</span>
                    </Link>
                  </Button>
                ))}
              </>
            )}
          </div>

          <div className="mt-auto pt-4">
            {otherLinks.map((item) => (
              <Button
                key={item.href}
                variant="ghost"
                asChild
                className={cn(
                  "w-full justify-start mb-1",
                  pathname === item.href && "bg-muted",
                  collapsed && "justify-center px-2",
                )}
              >
                <Link href={item.href}>
                  {item.icon}
                  {!collapsed && <span className="ml-2">{item.title}</span>}
                </Link>
              </Button>
            ))}
          </div>
        </div>
      </ScrollArea>
    </div>
  )
}
