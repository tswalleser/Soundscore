"use client"

import { useState } from "react"
import { Star } from "lucide-react"
import { cn } from "@/lib/utils"

interface StarRatingProps {
  rating: number
  onRatingChange: (rating: number) => void
  size?: number
  readOnly?: boolean
}

export function StarRating({ rating, onRatingChange, size = 20, readOnly = false }: StarRatingProps) {
  const [hoverRating, setHoverRating] = useState(0)

  const handleMouseEnter = (index: number) => {
    if (!readOnly) {
      setHoverRating(index)
    }
  }

  const handleMouseLeave = () => {
    if (!readOnly) {
      setHoverRating(0)
    }
  }

  const handleClick = (index: number) => {
    if (!readOnly) {
      onRatingChange(index === rating ? 0 : index)
    }
  }

  return (
    <div className="flex">
      {[1, 2, 3, 4, 5].map((index) => (
        <Star
          key={index}
          size={size}
          className={cn(
            "cursor-pointer transition-colors",
            hoverRating >= index || (!hoverRating && rating >= index)
              ? "text-primary fill-primary"
              : "text-muted-foreground",
            readOnly && "cursor-default",
          )}
          onMouseEnter={() => handleMouseEnter(index)}
          onMouseLeave={handleMouseLeave}
          onClick={() => handleClick(index)}
        />
      ))}
    </div>
  )
}
