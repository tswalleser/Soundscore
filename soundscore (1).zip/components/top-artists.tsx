import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Play } from "lucide-react"

export default function TopArtists() {
  const artists = [
    { name: "The Night Owls", cover: "/placeholder.svg?height=150&width=150" },
    { name: "Coastal Waves", cover: "/placeholder.svg?height=150&width=150" },
    { name: "Neon Pulse", cover: "/placeholder.svg?height=150&width=150" },
    { name: "Alpine Sounds", cover: "/placeholder.svg?height=150&width=150" },
    { name: "City Beats", cover: "/placeholder.svg?height=150&width=150" },
    { name: "Synth Masters", cover: "/placeholder.svg?height=150&width=150" },
  ]

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
      {artists.map((artist, index) => (
        <Card key={index} className="group relative overflow-hidden bg-card hover:bg-card/80 transition-colors">
          <CardContent className="p-4">
            <div className="relative aspect-square mb-3 rounded-full overflow-hidden">
              <Image src={artist.cover || "/placeholder.svg"} alt={artist.name} fill className="object-cover" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                  <Play className="h-5 w-5 text-white ml-0.5" />
                </div>
              </div>
            </div>
            <h3 className="font-medium text-sm text-center line-clamp-1">{artist.name}</h3>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
