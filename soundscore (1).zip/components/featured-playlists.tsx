import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Play } from "lucide-react"

export default function FeaturedPlaylists() {
  const playlists = [
    {
      title: "Chill Vibes",
      description: "Relaxing tunes for your downtime",
      cover: "/placeholder.svg?height=150&width=150",
    },
    {
      title: "Workout Mix",
      description: "High energy tracks to keep you moving",
      cover: "/placeholder.svg?height=150&width=150",
    },
    {
      title: "Focus Flow",
      description: "Concentration-enhancing instrumentals",
      cover: "/placeholder.svg?height=150&width=150",
    },
    {
      title: "Party Anthems",
      description: "Crowd favorites for any celebration",
      cover: "/placeholder.svg?height=150&width=150",
    },
  ]

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
      {playlists.map((playlist, index) => (
        <Card key={index} className="group relative overflow-hidden bg-card hover:bg-card/80 transition-colors">
          <CardContent className="p-4">
            <div className="relative aspect-square mb-3 rounded-md overflow-hidden">
              <Image src={playlist.cover || "/placeholder.svg"} alt={playlist.title} fill className="object-cover" />
              <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                  <Play className="h-5 w-5 text-white ml-0.5" />
                </div>
              </div>
            </div>
            <h3 className="font-medium text-sm line-clamp-1">{playlist.title}</h3>
            <p className="text-xs text-muted-foreground line-clamp-2">{playlist.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
