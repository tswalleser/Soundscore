import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Play, SkipForward } from "lucide-react"
import { StarRating } from "@/components/star-rating"

export default function DiscoverWeekly() {
  const songs = [
    { title: "Midnight Drive", artist: "Neon Pulse", duration: "3:45", rating: 0 },
    { title: "Ocean Waves", artist: "Coastal Dreams", duration: "4:12", rating: 0 },
    { title: "City Lights", artist: "Urban Echo", duration: "3:28", rating: 0 },
    { title: "Mountain High", artist: "Alpine Sounds", duration: "5:02", rating: 0 },
    { title: "Electric Feel", artist: "Synth Masters", duration: "3:56", rating: 0 },
  ]

  return (
    <div>
      <div className="flex items-center gap-4 mb-4">
        <div className="relative w-24 h-24 rounded-md overflow-hidden">
          <Image src="/placeholder.svg?height=96&width=96" alt="Discover Weekly" fill className="object-cover" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">Discover Weekly</h3>
          <p className="text-sm text-white/80">Updated May 4, 2025</p>
          <div className="flex gap-2 mt-2">
            <Button size="sm" className="bg-white text-dark-purple hover:bg-white/90">
              <Play className="h-4 w-4 mr-1 ml-0.5" /> Play
            </Button>
            <Button size="sm" variant="outline" className="border-white text-white hover:bg-white/20">
              Save
            </Button>
          </div>
        </div>
      </div>

      <div className="bg-black/20 rounded-lg p-4">
        {songs.map((song, index) => (
          <div key={index} className="flex items-center py-2 px-2 rounded-md hover:bg-white/10 transition-colors group">
            <div className="w-8 text-center text-white/60 group-hover:hidden">{index + 1}</div>
            <div className="w-8 text-center hidden group-hover:block">
              <Play className="h-4 w-4 text-white mx-auto" />
            </div>
            <div className="flex-1 ml-2">
              <div className="text-sm font-medium text-white">{song.title}</div>
              <div className="text-xs text-white/60">{song.artist}</div>
            </div>
            <div className="w-24 flex justify-center">
              <StarRating rating={song.rating} onRatingChange={() => {}} size={16} />
            </div>
            <div className="w-12 text-right text-xs text-white/60">{song.duration}</div>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-white/60 hover:text-white">
              <SkipForward className="h-4 w-4" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  )
}
