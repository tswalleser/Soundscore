"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { cn } from "@/lib/utils"
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Repeat,
  Shuffle,
  Volume2,
  VolumeX,
  Heart,
  ListMusic,
  Maximize2,
  Star,
} from "lucide-react"
import { StarRating } from "@/components/star-rating"

export default function Player() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState(70)
  const [progress, setProgress] = useState(0)
  const [isMuted, setIsMuted] = useState(false)
  const [showRating, setShowRating] = useState(false)
  const [currentRating, setCurrentRating] = useState(0)
  const [liked, setLiked] = useState(false)

  // Simulate progress when playing
  useEffect(() => {
    let interval: NodeJS.Timeout

    if (isPlaying) {
      interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval)
            setIsPlaying(false)
            return 0
          }
          return prev + 0.5
        })
      }, 1000)
    }

    return () => clearInterval(interval)
  }, [isPlaying])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  // Convert progress percentage to seconds (assuming 3:30 song length)
  const progressToSeconds = (percent: number) => {
    return (percent / 100) * 210 // 3:30 = 210 seconds
  }

  return (
    <div className="h-20 bg-card border-t flex items-center px-4 py-2">
      <div className="flex items-center w-1/4">
        <div className="relative h-14 w-14 rounded-md overflow-hidden mr-3">
          <Image
            src="/placeholder.svg?height=56&width=56"
            alt="Album cover"
            width={56}
            height={56}
            className="object-cover"
          />
        </div>
        <div>
          <h4 className="text-sm font-medium line-clamp-1">Song Title</h4>
          <p className="text-xs text-muted-foreground line-clamp-1">Artist Name</p>
        </div>
        <div className="flex ml-4">
          <Button
            variant="ghost"
            size="icon"
            className={cn("h-8 w-8", liked && "text-primary")}
            onClick={() => setLiked(!liked)}
          >
            <Heart className="h-4 w-4" fill={liked ? "currentColor" : "none"} />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowRating(!showRating)}>
            <Star className="h-4 w-4" />
          </Button>
        </div>

        {showRating && (
          <div className="absolute bottom-24 left-4 bg-card p-3 rounded-lg shadow-lg border z-10">
            <p className="text-sm font-medium mb-2">Rate this song</p>
            <StarRating rating={currentRating} onRatingChange={setCurrentRating} size={24} />
          </div>
        )}
      </div>

      <div className="flex-1 flex flex-col items-center justify-center max-w-xl mx-auto">
        <div className="flex items-center gap-2 mb-1">
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Shuffle className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <SkipBack className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-10 w-10 rounded-full bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={() => setIsPlaying(!isPlaying)}
          >
            {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 ml-0.5" />}
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <SkipForward className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <Repeat className="h-4 w-4" />
          </Button>
        </div>

        <div className="w-full flex items-center gap-2">
          <span className="text-xs w-10 text-right">{formatTime(progressToSeconds(progress))}</span>
          <Slider
            value={[progress]}
            max={100}
            step={0.1}
            className="progress-slider"
            style={{ "--progress": `${progress}%` } as React.CSSProperties}
            onValueChange={(value) => setProgress(value[0])}
          />
          <span className="text-xs w-10">3:30</span>
        </div>
      </div>

      <div className="w-1/4 flex items-center justify-end gap-2">
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <ListMusic className="h-4 w-4" />
        </Button>
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setIsMuted(!isMuted)}>
          {isMuted || volume === 0 ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
        </Button>
        <Slider
          value={[isMuted ? 0 : volume]}
          max={100}
          step={1}
          className="volume-slider w-24"
          onValueChange={(value) => setVolume(value[0])}
        />
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <Maximize2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
