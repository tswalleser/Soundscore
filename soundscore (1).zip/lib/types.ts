export interface User {
  id: string
  email: string
  username?: string
  full_name?: string
  avatar_url?: string
}

export interface Song {
  id: string
  title: string
  artist_id: string
  album_id?: string
  duration: number
  file_url: string
  cover_url?: string
  uploaded_by: string
  is_public: boolean
  created_at: string
  updated_at: string

  // Joined fields
  artist_name?: string
  album_title?: string
  user_rating?: number
}

export interface Album {
  id: string
  title: string
  artist_id: string
  cover_url?: string
  release_date?: string
  created_at: string
  updated_at: string

  // Joined fields
  artist_name?: string
}

export interface Artist {
  id: string
  name: string
  bio?: string
  image_url?: string
  created_at: string
  updated_at: string
}

export interface Playlist {
  id: string
  name: string
  description?: string
  cover_url?: string
  user_id: string
  is_public: boolean
  created_at: string
  updated_at: string

  // Joined fields
  song_count?: number
}

export interface Rating {
  id: string
  user_id: string
  song_id: string
  rating: number
  created_at: string
  updated_at: string
}

export interface Listen {
  id: string
  user_id: string
  song_id: string
  listened_at: string
}

export interface Genre {
  id: string
  name: string
}
