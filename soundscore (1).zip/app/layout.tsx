import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import Player from "@/components/player"
import Sidebar from "@/components/sidebar"
import { Toaster } from "@/components/ui/toaster"
import { Providers } from "./providers"

// Add this line right after the imports to verify Supabase connection
// This will run on the client and help identify if there are connection issues
try {
  // Simple health check - we'll import supabase only in client components
} catch (error) {
  console.error("Failed to initialize Supabase client:", error)
}

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "SoundScore",
  description: "Music streaming platform with song ratings and personalized recommendations",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>
          <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
            <div className="flex flex-col h-screen bg-[#1A0D23]">
              <div className="flex flex-1 overflow-hidden">
                <Sidebar />
                <main className="flex-1 overflow-auto p-4 md:p-6">{children}</main>
              </div>
              <Player />
              <Toaster />
            </div>
          </ThemeProvider>
        </Providers>
      </body>
    </html>
  )
}
