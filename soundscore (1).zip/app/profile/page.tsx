import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Image from "next/image"
import { Edit, Share2, UserPlus } from "lucide-react"

export default function ProfilePage() {
  const stats = [
    { label: "Following", value: 128 },
    { label: "Followers", value: 843 },
    { label: "Playlists", value: 24 },
  ]

  const topGenres = [
    { name: "Electronic", percentage: 35 },
    { name: "Pop", percentage: 25 },
    { name: "Rock", percentage: 20 },
    { name: "Hip Hop", percentage: 15 },
    { name: "Jazz", percentage: 5 },
  ]

  const listeningActivity = [
    { day: "Mon", hours: 2.5 },
    { day: "Tue", hours: 1.8 },
    { day: "Wed", hours: 3.2 },
    { day: "Thu", hours: 2.1 },
    { day: "Fri", hours: 4.5 },
    { day: "Sat", hours: 5.2 },
    { day: "Sun", hours: 3.7 },
  ]

  const maxHours = Math.max(...listeningActivity.map((day) => day.hours))

  return (
    <div className="space-y-6">
      <div className="relative h-48 md:h-64 rounded-xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-dark-purple to-raspberry opacity-80" />
        <div className="absolute inset-0 flex items-end p-6">
          <div className="flex items-end gap-6">
            <div className="relative w-24 h-24 md:w-32 md:h-32 rounded-full border-4 border-background overflow-hidden">
              <Image src="/placeholder.svg?height=128&width=128" alt="Profile picture" fill className="object-cover" />
            </div>
            <div className="mb-2">
              <h1 className="text-3xl font-bold text-white">John Doe</h1>
              <p className="text-white/80">@johndoe</p>
            </div>
          </div>
          <div className="ml-auto flex gap-2">
            <Button variant="outline" size="sm" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
              <Edit className="h-4 w-4 mr-2" /> Edit Profile
            </Button>
            <Button variant="outline" size="sm" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
              <Share2 className="h-4 w-4 mr-2" /> Share
            </Button>
            <Button variant="outline" size="sm" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
              <UserPlus className="h-4 w-4 mr-2" /> Follow
            </Button>
          </div>
        </div>
      </div>

      <div className="flex gap-4 flex-wrap">
        {stats.map((stat, index) => (
          <Card key={index} className="flex-1 min-w-[120px]">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold">{stat.value}</p>
              <p className="text-sm text-muted-foreground">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="playlists">Playlists</TabsTrigger>
          <TabsTrigger value="artists">Artists</TabsTrigger>
          <TabsTrigger value="songs">Songs</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Genres</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {topGenres.map((genre, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>{genre.name}</span>
                        <span>{genre.percentage}%</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary" style={{ width: `${genre.percentage}%` }} />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Weekly Listening Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end h-40 gap-2">
                  {listeningActivity.map((day, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center gap-2">
                      <div
                        className="w-full bg-primary rounded-t-sm"
                        style={{ height: `${(day.hours / maxHours) * 100}%` }}
                      />
                      <span className="text-xs text-muted-foreground">{day.day}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Listening Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Minutes Streamed</p>
                    <p className="text-2xl font-bold">45,231</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Songs Played</p>
                    <p className="text-2xl font-bold">12,543</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Artists Discovered</p>
                    <p className="text-2xl font-bold">342</p>
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-muted-foreground">Songs Rated</p>
                    <p className="text-2xl font-bold">1,245</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="playlists">
          <p className="text-muted-foreground text-center py-8">Your playlists will appear here</p>
        </TabsContent>

        <TabsContent value="artists">
          <p className="text-muted-foreground text-center py-8">Your favorite artists will appear here</p>
        </TabsContent>

        <TabsContent value="songs">
          <p className="text-muted-foreground text-center py-8">Your favorite songs will appear here</p>
        </TabsContent>
      </Tabs>
    </div>
  )
}
