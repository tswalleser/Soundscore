import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const error = searchParams.get("error")

  let errorMessage = "An unknown error occurred"

  switch (error) {
    case "Configuration":
      errorMessage = "There is a problem with the server configuration."
      break
    case "AccessDenied":
      errorMessage = "You do not have access to this resource."
      break
    case "Verification":
      errorMessage = "The verification link may have expired or already been used."
      break
    case "CredentialsSignin":
      errorMessage = "The email or password you entered is incorrect."
      break
    case "Default":
      errorMessage = "An authentication error occurred. Please try again."
      break
    case "SessionRequired":
      errorMessage = "You must be signed in to access this page."
      break
    default:
      errorMessage = `Authentication error: ${error || "Unknown"}`
  }

  return NextResponse.json({ error: errorMessage }, { status: 400 })
}
