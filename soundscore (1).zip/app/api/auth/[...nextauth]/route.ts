import NextAuth from "next-auth"
import CredentialsProvider from "next-auth/providers/credentials"
import { supabase } from "@/lib/supabase"

const authOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          throw new Error("Please enter your email and password")
        }

        try {
          // Sign in with Supabase Auth
          const { data, error } = await supabase.auth.signInWithPassword({
            email: credentials.email,
            password: credentials.password,
          })

          if (error) {
            console.error("Supabase auth error:", error)
            throw new Error(error.message || "Invalid credentials")
          }

          if (!data.user) {
            throw new Error("No user found")
          }

          // Get user profile
          const { data: profileData, error: profileError } = await supabase
            .from("profiles")
            .select("*")
            .eq("id", data.user.id)
            .single()

          if (profileError) {
            console.error("Profile fetch error:", profileError)
            // Continue even if profile fetch fails
          }

          return {
            id: data.user.id,
            email: data.user.email,
            name: profileData?.full_name || data.user.email?.split("@")[0],
            image: profileData?.avatar_url,
          }
        } catch (error: any) {
          console.error("Auth error:", error)
          throw new Error(error.message || "Authentication failed")
        }
      },
    }),
  ],
  pages: {
    signIn: "/login",
    error: "/auth/error",
    signOut: "/",
  },
  callbacks: {
    async jwt({ token, user }) {
      // Initial sign in
      if (user) {
        return {
          ...token,
          sub: user.id,
        }
      }

      return token
    },
    async session({ session, token }) {
      if (token && session.user) {
        session.user.id = token.sub as string
      }
      return session
    },
  },
  // Add a secret for JWT signing
  secret: process.env.NEXTAUTH_SECRET || "soundscore-secret-key",
  debug: process.env.NODE_ENV === "development",
}

const handler = NextAuth(authOptions)

export { handler as GET, handler as POST }
