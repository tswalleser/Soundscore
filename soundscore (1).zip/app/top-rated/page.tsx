import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import Image from "next/image"
import { Play, Filter } from "lucide-react"
import { StarRating } from "@/components/star-rating"

export default function TopRatedPage() {
  const topRatedSongs = [
    {
      title: "Neon Dreams",
      artist: "Synthwave Masters",
      album: "Electric Horizons",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 5,
    },
    {
      title: "Ocean Breeze",
      artist: "Coastal Sounds",
      album: "Seaside Melodies",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 5,
    },
    {
      title: "Mountain Echo",
      artist: "Alpine Collective",
      album: "Summit Views",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 5,
    },
    {
      title: "Urban Jungle",
      artist: "City Beats",
      album: "Metropolitan",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 4,
    },
    {
      title: "Midnight Drive",
      artist: "Night Owls",
      album: "After Hours",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 4,
    },
    {
      title: "Summer Vibes",
      artist: "Beach Collective",
      album: "Sunshine Days",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 4,
    },
    {
      title: "Autumn Leaves",
      artist: "Seasonal Sounds",
      album: "Fall Collection",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 4,
    },
    {
      title: "Winter Wonderland",
      artist: "Frost Ensemble",
      album: "Snow Crystals",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 4,
    },
    {
      title: "Spring Awakening",
      artist: "Bloom Quartet",
      album: "New Beginnings",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 4,
    },
    {
      title: "Desert Mirage",
      artist: "Sand Drifters",
      album: "Oasis Dreams",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 4,
    },
  ]

  const topRatedAlbums = [
    {
      title: "Electric Horizons",
      artist: "Synthwave Masters",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 5,
      songs: 12,
    },
    {
      title: "Seaside Melodies",
      artist: "Coastal Sounds",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 5,
      songs: 10,
    },
    {
      title: "Summit Views",
      artist: "Alpine Collective",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 5,
      songs: 8,
    },
    {
      title: "Metropolitan",
      artist: "City Beats",
      cover: "/placeholder.svg?height=150&width=150",
      rating: 4,
      songs: 14,
    },
    { title: "After Hours", artist: "Night Owls", cover: "/placeholder.svg?height=150&width=150", rating: 4, songs: 9 },
  ]

  const topRatedArtists = [
    { name: "Synthwave Masters", cover: "/placeholder.svg?height=150&width=150", rating: 5 },
    { name: "Coastal Sounds", cover: "/placeholder.svg?height=150&width=150", rating: 5 },
    { name: "Alpine Collective", cover: "/placeholder.svg?height=150&width=150", rating: 5 },
    { name: "City Beats", cover: "/placeholder.svg?height=150&width=150", rating: 4 },
    { name: "Night Owls", cover: "/placeholder.svg?height=150&width=150", rating: 4 },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Your Top Rated</h1>
        <Button variant="outline" size="sm">
          <Filter className="h-4 w-4 mr-2" /> Filter
        </Button>
      </div>

      <Tabs defaultValue="songs" className="space-y-6">
        <TabsList>
          <TabsTrigger value="songs">Songs</TabsTrigger>
          <TabsTrigger value="albums">Albums</TabsTrigger>
          <TabsTrigger value="artists">Artists</TabsTrigger>
        </TabsList>

        <TabsContent value="songs" className="space-y-6">
          <div className="bg-card rounded-lg overflow-hidden">
            <div className="grid grid-cols-12 py-2 px-4 border-b text-sm font-medium text-muted-foreground">
              <div className="col-span-1">#</div>
              <div className="col-span-5">Title</div>
              <div className="col-span-3">Album</div>
              <div className="col-span-2">Rating</div>
              <div className="col-span-1 text-right">Duration</div>
            </div>

            {topRatedSongs.map((song, index) => (
              <div key={index} className="grid grid-cols-12 py-2 px-4 items-center hover:bg-muted/50 group">
                <div className="col-span-1 text-muted-foreground group-hover:hidden">{index + 1}</div>
                <div className="col-span-1 hidden group-hover:block">
                  <Play className="h-4 w-4" />
                </div>
                <div className="col-span-5 flex items-center gap-3">
                  <div className="relative w-10 h-10 rounded overflow-hidden">
                    <Image src={song.cover || "/placeholder.svg"} alt={song.title} fill className="object-cover" />
                  </div>
                  <div>
                    <div className="font-medium">{song.title}</div>
                    <div className="text-sm text-muted-foreground">{song.artist}</div>
                  </div>
                </div>
                <div className="col-span-3 text-muted-foreground">{song.album}</div>
                <div className="col-span-2">
                  <StarRating rating={song.rating} onRatingChange={() => {}} size={16} />
                </div>
                <div className="col-span-1 text-right text-muted-foreground">3:45</div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="albums" className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {topRatedAlbums.map((album, index) => (
              <Card key={index} className="group relative overflow-hidden bg-card hover:bg-card/80 transition-colors">
                <CardContent className="p-4">
                  <div className="relative aspect-square mb-3 rounded-md overflow-hidden">
                    <Image src={album.cover || "/placeholder.svg"} alt={album.title} fill className="object-cover" />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                        <Play className="h-5 w-5 text-white ml-0.5" />
                      </div>
                    </div>
                  </div>
                  <h3 className="font-medium text-sm line-clamp-1">{album.title}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-1 mb-1">
                    {album.artist} • {album.songs} songs
                  </p>
                  <StarRating rating={album.rating} onRatingChange={() => {}} size={14} readOnly />
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="artists" className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {topRatedArtists.map((artist, index) => (
              <Card key={index} className="group relative overflow-hidden bg-card hover:bg-card/80 transition-colors">
                <CardContent className="p-4">
                  <div className="relative aspect-square mb-3 rounded-full overflow-hidden">
                    <Image src={artist.cover || "/placeholder.svg"} alt={artist.name} fill className="object-cover" />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                        <Play className="h-5 w-5 text-white ml-0.5" />
                      </div>
                    </div>
                  </div>
                  <h3 className="font-medium text-sm text-center line-clamp-1">{artist.name}</h3>
                  <div className="flex justify-center mt-1">
                    <StarRating rating={artist.rating} onRatingChange={() => {}} size={14} readOnly />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
