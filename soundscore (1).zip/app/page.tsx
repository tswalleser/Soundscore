import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import RecentlyPlayed from "@/components/recently-played"
import TopArtists from "@/components/top-artists"
import FeaturedPlaylists from "@/components/featured-playlists"
import DiscoverWeekly from "@/components/discover-weekly"
import TopRated from "@/components/top-rated"

export default function Home() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Home</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            Upgrade
          </Button>
        </div>
      </div>

      <Tabs defaultValue="for-you" className="space-y-6">
        <TabsList>
          <TabsTrigger value="for-you">For You</TabsTrigger>
          <TabsTrigger value="discover">Discover</TabsTrigger>
          <TabsTrigger value="stats">Your Stats</TabsTrigger>
        </TabsList>

        <TabsContent value="for-you" className="space-y-6">
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold">Recently Played</h2>
              <Button variant="link" className="text-primary">
                See all
              </Button>
            </div>
            <RecentlyPlayed />
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold">Your Top Artists</h2>
              <Button variant="link" className="text-primary">
                See all
              </Button>
            </div>
            <TopArtists />
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold">Featured Playlists</h2>
              <Button variant="link" className="text-primary">
                See all
              </Button>
            </div>
            <FeaturedPlaylists />
          </section>
        </TabsContent>

        <TabsContent value="discover" className="space-y-6">
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold">Your SoundScore Weekly</h2>
              <Button variant="link" className="text-primary">
                Refresh
              </Button>
            </div>
            <Card className="bg-gradient-to-br from-dark-purple to-raspberry border-none">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2 text-white">Discover Weekly</h3>
                <p className="text-sm text-white/80 mb-4">
                  Your personal playlist, updated every Monday with fresh discoveries and new releases based on your
                  listening habits and ratings.
                </p>
                <DiscoverWeekly />
              </CardContent>
            </Card>
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold">Based on Your Ratings</h2>
              <Button variant="link" className="text-primary">
                See all
              </Button>
            </div>
            <TopRated />
          </section>
        </TabsContent>

        <TabsContent value="stats" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Listening Activity</h3>
                <div className="h-64 flex items-center justify-center bg-muted rounded-md">
                  <p className="text-muted-foreground">Weekly listening chart will appear here</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Top Genres</h3>
                <div className="h-64 flex items-center justify-center bg-muted rounded-md">
                  <p className="text-muted-foreground">Genre distribution chart will appear here</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Highest Rated</h3>
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-muted rounded-md flex items-center justify-center">
                        <span className="font-bold">{i}</span>
                      </div>
                      <div>
                        <p className="font-medium">Song Title {i}</p>
                        <p className="text-sm text-muted-foreground">Artist Name</p>
                      </div>
                      <div className="ml-auto flex">
                        {Array.from({ length: 5 }).map((_, j) => (
                          <span key={j} className="text-primary">
                            ★
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-4">Listening Time</h3>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Today</span>
                    <span className="font-medium">1h 23m</span>
                  </div>
                  <div className="flex justify-between">
                    <span>This Week</span>
                    <span className="font-medium">8h 45m</span>
                  </div>
                  <div className="flex justify-between">
                    <span>This Month</span>
                    <span className="font-medium">42h 12m</span>
                  </div>
                  <div className="flex justify-between">
                    <span>All Time</span>
                    <span className="font-medium">1,245h 30m</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
