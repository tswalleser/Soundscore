import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"
import { Play, Plus, Music } from "lucide-react"

export default function LibraryPage() {
  const playlists = [
    {
      name: "Liked Songs",
      description: "1,245 songs",
      image: "/placeholder.svg?height=150&width=150",
      icon: <Music className="h-6 w-6" />,
    },
    { name: "Your Top Songs 2024", description: "100 songs", image: "/placeholder.svg?height=150&width=150" },
    {
      name: "Discover Weekly",
      description: "30 songs • Updated weekly",
      image: "/placeholder.svg?height=150&width=150",
    },
    { name: "Chill Vibes", description: "Created by you • 45 songs", image: "/placeholder.svg?height=150&width=150" },
    { name: "Workout Mix", description: "Created by you • 32 songs", image: "/placeholder.svg?height=150&width=150" },
    { name: "Road Trip", description: "Created by you • 78 songs", image: "/placeholder.svg?height=150&width=150" },
  ]

  const artists = [
    { name: "The Night Owls", image: "/placeholder.svg?height=150&width=150" },
    { name: "Coastal Waves", image: "/placeholder.svg?height=150&width=150" },
    { name: "Neon Pulse", image: "/placeholder.svg?height=150&width=150" },
    { name: "Alpine Sounds", image: "/placeholder.svg?height=150&width=150" },
    { name: "City Beats", image: "/placeholder.svg?height=150&width=150" },
    { name: "Synth Masters", image: "/placeholder.svg?height=150&width=150" },
  ]

  const albums = [
    { name: "Midnight Memories", artist: "The Night Owls", image: "/placeholder.svg?height=150&width=150" },
    { name: "Ocean Breeze", artist: "Coastal Waves", image: "/placeholder.svg?height=150&width=150" },
    { name: "Electric Dreams", artist: "Neon Pulse", image: "/placeholder.svg?height=150&width=150" },
    { name: "Mountain Echo", artist: "Alpine Sounds", image: "/placeholder.svg?height=150&width=150" },
    { name: "Urban Jungle", artist: "City Beats", image: "/placeholder.svg?height=150&width=150" },
    { name: "Retro Wave", artist: "Synth Masters", image: "/placeholder.svg?height=150&width=150" },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Your Library</h1>
        <Button variant="outline" size="icon">
          <Plus className="h-4 w-4" />
        </Button>
      </div>

      <div className="flex items-center gap-2">
        <Input type="search" placeholder="Search in Your Library" className="max-w-xs" />
        <Button variant="outline" size="sm">
          Recents
        </Button>
        <Button variant="outline" size="sm">
          Added
        </Button>
        <Button variant="outline" size="sm">
          Alphabetical
        </Button>
      </div>

      <Tabs defaultValue="playlists" className="space-y-6">
        <TabsList>
          <TabsTrigger value="playlists">Playlists</TabsTrigger>
          <TabsTrigger value="artists">Artists</TabsTrigger>
          <TabsTrigger value="albums">Albums</TabsTrigger>
        </TabsList>

        <TabsContent value="playlists" className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {playlists.map((playlist, index) => (
              <Card key={index} className="group relative overflow-hidden bg-card hover:bg-card/80 transition-colors">
                <CardContent className="p-4">
                  <div className="relative aspect-square mb-3 rounded-md overflow-hidden bg-muted">
                    {playlist.icon ? (
                      <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-primary to-secondary">
                        {playlist.icon}
                      </div>
                    ) : (
                      <Image
                        src={playlist.image || "/placeholder.svg"}
                        alt={playlist.name}
                        fill
                        className="object-cover"
                      />
                    )}
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                        <Play className="h-5 w-5 text-white ml-0.5" />
                      </div>
                    </div>
                  </div>
                  <h3 className="font-medium text-sm line-clamp-1">{playlist.name}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-1">{playlist.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="artists" className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {artists.map((artist, index) => (
              <Card key={index} className="group relative overflow-hidden bg-card hover:bg-card/80 transition-colors">
                <CardContent className="p-4">
                  <div className="relative aspect-square mb-3 rounded-full overflow-hidden">
                    <Image src={artist.image || "/placeholder.svg"} alt={artist.name} fill className="object-cover" />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                        <Play className="h-5 w-5 text-white ml-0.5" />
                      </div>
                    </div>
                  </div>
                  <h3 className="font-medium text-sm text-center line-clamp-1">{artist.name}</h3>
                  <p className="text-xs text-muted-foreground text-center">Artist</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="albums" className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {albums.map((album, index) => (
              <Card key={index} className="group relative overflow-hidden bg-card hover:bg-card/80 transition-colors">
                <CardContent className="p-4">
                  <div className="relative aspect-square mb-3 rounded-md overflow-hidden">
                    <Image src={album.image || "/placeholder.svg"} alt={album.name} fill className="object-cover" />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                        <Play className="h-5 w-5 text-white ml-0.5" />
                      </div>
                    </div>
                  </div>
                  <h3 className="font-medium text-sm line-clamp-1">{album.name}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-1">{album.artist}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
