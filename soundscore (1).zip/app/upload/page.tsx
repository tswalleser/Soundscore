"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { useToast } from "@/hooks/use-toast"
import { supabase } from "@/lib/supabase"
import { Upload, Music, ImageIcon, Loader2 } from "lucide-react"
import { useSession } from "next-auth/react"

export default function UploadPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { toast } = useToast()

  const [title, setTitle] = useState("")
  const [artistName, setArtistName] = useState("")
  const [albumTitle, setAlbumTitle] = useState("")
  const [isPublic, setIsPublic] = useState(true)
  const [songFile, setSongFile] = useState<File | null>(null)
  const [coverFile, setCoverFile] = useState<File | null>(null)
  const [songFilePreview, setSongFilePreview] = useState<string>("")
  const [coverFilePreview, setCoverFilePreview] = useState<string>("")
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)

  // Redirect to login if not authenticated
  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login?callbackUrl=/upload")
    }
  }, [status, router])

  const handleSongFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setSongFile(file)
      setSongFilePreview(file.name)
    }
  }

  const handleCoverFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setCoverFile(file)
      setCoverFilePreview(URL.createObjectURL(file))
    }
  }

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!session?.user?.id) {
      toast({
        title: "Authentication required",
        description: "Please sign in to upload songs",
        variant: "destructive",
      })
      return
    }

    if (!songFile) {
      toast({
        title: "Song file required",
        description: "Please select an audio file to upload",
        variant: "destructive",
      })
      return
    }

    if (!title || !artistName) {
      toast({
        title: "Missing information",
        description: "Please provide a title and artist name",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)
    setUploadProgress(0)

    try {
      // 1. Upload song file
      const songFileName = `${session.user.id}/${Date.now()}-${songFile.name}`
      const { data: songData, error: songError } = await supabase.storage.from("songs").upload(songFileName, songFile, {
        cacheControl: "3600",
        upsert: false,
      })

      if (songError) throw songError

      setUploadProgress(50)

      // 2. Upload cover file if provided
      let coverUrl = null
      if (coverFile) {
        const coverFileName = `${session.user.id}/${Date.now()}-${coverFile.name}`
        const { data: coverData, error: coverError } = await supabase.storage
          .from("covers")
          .upload(coverFileName, coverFile, {
            cacheControl: "3600",
            upsert: false,
          })

        if (coverError) throw coverError

        const { data: coverUrlData } = supabase.storage.from("covers").getPublicUrl(coverFileName)

        if (coverUrlData) {
          coverUrl = coverUrlData.publicUrl
        }
      }

      setUploadProgress(75)

      // 3. Get song file URL
      const { data: songUrl } = supabase.storage.from("songs").getPublicUrl(songFileName)

      if (!songUrl) throw new Error("Failed to get song URL")

      // 4. Create artist if needed
      const { data: existingArtists, error: artistError } = await supabase
        .from("artists")
        .select("id, name")
        .eq("name", artistName)
        .limit(1)

      if (artistError) throw artistError

      let artistId
      if (existingArtists && existingArtists.length > 0) {
        artistId = existingArtists[0].id
      } else {
        const { data: newArtist, error: newArtistError } = await supabase
          .from("artists")
          .insert([{ name: artistName }])
          .select()

        if (newArtistError) throw newArtistError
        artistId = newArtist[0].id
      }

      // 5. Create album if provided
      let albumId = null
      if (albumTitle) {
        const { data: existingAlbums, error: albumError } = await supabase
          .from("albums")
          .select("id, title")
          .eq("title", albumTitle)
          .eq("artist_id", artistId)
          .limit(1)

        if (albumError) throw albumError

        if (existingAlbums && existingAlbums.length > 0) {
          albumId = existingAlbums[0].id
        } else {
          const { data: newAlbum, error: newAlbumError } = await supabase
            .from("albums")
            .insert([
              {
                title: albumTitle,
                artist_id: artistId,
                cover_url: coverUrl,
              },
            ])
            .select()

          if (newAlbumError) throw newAlbumError
          albumId = newAlbum[0].id
        }
      }

      // 6. Create song entry
      const { data: newSong, error: songInsertError } = await supabase
        .from("songs")
        .insert([
          {
            title,
            artist_id: artistId,
            album_id: albumId,
            duration: 0, // We'll update this later
            file_url: songUrl.publicUrl,
            cover_url: coverUrl,
            uploaded_by: session.user.id,
            is_public: isPublic,
          },
        ])
        .select()

      if (songInsertError) throw songInsertError

      setUploadProgress(100)

      toast({
        title: "Upload successful",
        description: "Your song has been uploaded successfully",
      })

      // Redirect to the song page
      router.push(`/song/${newSong[0].id}`)
    } catch (error) {
      console.error("Upload error:", error)
      toast({
        title: "Upload failed",
        description: "There was an error uploading your song. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  // Show loading state while checking authentication
  if (status === "loading") {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  // If not authenticated, this will redirect via the useEffect
  if (status === "unauthenticated") {
    return (
      <div className="max-w-3xl mx-auto py-6 text-center">
        <h1 className="text-3xl font-bold mb-6">Upload Your Music</h1>
        <Card>
          <CardContent className="p-6">
            <p className="mb-4">You need to be signed in to upload music.</p>
            <Button onClick={() => router.push("/login?callbackUrl=/upload")}>Sign In</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="max-w-3xl mx-auto py-6">
      <h1 className="text-3xl font-bold mb-6">Upload Your Music</h1>

      <Card>
        <CardHeader>
          <CardTitle>Song Details</CardTitle>
          <CardDescription>Fill in the details about your song and upload the audio file.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleUpload} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Song Title *</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter song title"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="artist">Artist Name *</Label>
                  <Input
                    id="artist"
                    value={artistName}
                    onChange={(e) => setArtistName(e.target.value)}
                    placeholder="Enter artist name"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="album">Album Title (Optional)</Label>
                  <Input
                    id="album"
                    value={albumTitle}
                    onChange={(e) => setAlbumTitle(e.target.value)}
                    placeholder="Enter album title"
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="isPublic"
                    checked={isPublic}
                    onCheckedChange={(checked) => setIsPublic(checked as boolean)}
                  />
                  <Label htmlFor="isPublic">Make this song public</Label>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="songFile">Song File *</Label>
                  <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                    <input
                      type="file"
                      id="songFile"
                      accept="audio/*"
                      onChange={handleSongFileChange}
                      className="hidden"
                    />
                    {songFilePreview ? (
                      <div className="text-center">
                        <Music className="h-8 w-8 mx-auto mb-2 text-primary" />
                        <p className="text-sm font-medium">{songFilePreview}</p>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setSongFile(null)
                            setSongFilePreview("")
                          }}
                        >
                          Change
                        </Button>
                      </div>
                    ) : (
                      <label htmlFor="songFile" className="cursor-pointer text-center">
                        <Music className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm font-medium">Click to select audio file</p>
                        <p className="text-xs text-muted-foreground">MP3, WAV, FLAC (max 50MB)</p>
                      </label>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="coverFile">Cover Art (Optional)</Label>
                  <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                    <input
                      type="file"
                      id="coverFile"
                      accept="image/*"
                      onChange={handleCoverFileChange}
                      className="hidden"
                    />
                    {coverFilePreview ? (
                      <div className="text-center">
                        <div className="w-24 h-24 mx-auto mb-2 rounded-md overflow-hidden">
                          <img
                            src={coverFilePreview || "/placeholder.svg"}
                            alt="Cover preview"
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setCoverFile(null)
                            setCoverFilePreview("")
                          }}
                        >
                          Change
                        </Button>
                      </div>
                    ) : (
                      <label htmlFor="coverFile" className="cursor-pointer text-center">
                        <ImageIcon className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm font-medium">Click to select cover image</p>
                        <p className="text-xs text-muted-foreground">JPG, PNG (max 5MB)</p>
                      </label>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {isUploading && (
              <div className="w-full bg-muted rounded-full h-2.5">
                <div className="bg-primary h-2.5 rounded-full" style={{ width: `${uploadProgress}%` }}></div>
              </div>
            )}

            <div className="flex justify-end">
              <Button
                type="submit"
                disabled={isUploading || !songFile || !title || !artistName}
                className="w-full md:w-auto"
              >
                {isUploading ? "Uploading..." : "Upload Song"}
                {!isUploading && <Upload className="ml-2 h-4 w-4" />}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
