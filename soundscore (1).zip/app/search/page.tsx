import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import Image from "next/image"
import { Play } from "lucide-react"

export default function SearchPage() {
  const categories = [
    { name: "Pop", color: "from-raspberry to-dark-purple", image: "/placeholder.svg?height=150&width=150" },
    { name: "Rock", color: "from-dark-purple to-periwinkle", image: "/placeholder.svg?height=150&width=150" },
    { name: "Hip Hop", color: "from-periwinkle to-raspberry", image: "/placeholder.svg?height=150&width=150" },
    { name: "Electronic", color: "from-raspberry to-periwinkle", image: "/placeholder.svg?height=150&width=150" },
    { name: "Jazz", color: "from-dark-purple to-raspberry", image: "/placeholder.svg?height=150&width=150" },
    { name: "Classical", color: "from-periwinkle to-dark-purple", image: "/placeholder.svg?height=150&width=150" },
    { name: "R&B", color: "from-raspberry to-dark-purple", image: "/placeholder.svg?height=150&width=150" },
    { name: "Country", color: "from-dark-purple to-periwinkle", image: "/placeholder.svg?height=150&width=150" },
  ]

  const topResults = [
    { type: "Artist", name: "The Night Owls", image: "/placeholder.svg?height=150&width=150" },
    {
      type: "Album",
      name: "Midnight Memories",
      artist: "The Night Owls",
      image: "/placeholder.svg?height=150&width=150",
    },
    { type: "Song", name: "Midnight Drive", artist: "The Night Owls", image: "/placeholder.svg?height=150&width=150" },
    { type: "Playlist", name: "Night Vibes", image: "/placeholder.svg?height=150&width=150" },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Search</h1>
      </div>

      <div className="max-w-xl">
        <Input type="search" placeholder="What do you want to listen to?" className="h-12 bg-card" />
      </div>

      <Tabs defaultValue="all" className="space-y-6">
        <TabsList>
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="songs">Songs</TabsTrigger>
          <TabsTrigger value="artists">Artists</TabsTrigger>
          <TabsTrigger value="albums">Albums</TabsTrigger>
          <TabsTrigger value="playlists">Playlists</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-6">
          <section>
            <h2 className="text-2xl font-semibold mb-4">Top Results</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {topResults.map((result, index) => (
                <Card key={index} className="group relative overflow-hidden bg-card hover:bg-card/80 transition-colors">
                  <CardContent className="p-4">
                    <div
                      className={`relative ${result.type === "Artist" ? "aspect-square rounded-full" : "aspect-square rounded-md"} mb-3 overflow-hidden`}
                    >
                      <Image src={result.image || "/placeholder.svg"} alt={result.name} fill className="object-cover" />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                          <Play className="h-5 w-5 text-white ml-0.5" />
                        </div>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground mb-1">{result.type}</div>
                    <h3 className="font-medium text-sm line-clamp-1">{result.name}</h3>
                    {result.artist && <p className="text-xs text-muted-foreground line-clamp-1">{result.artist}</p>}
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">Browse All</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {categories.map((category, index) => (
                <div
                  key={index}
                  className={`relative h-40 rounded-lg overflow-hidden bg-gradient-to-br ${category.color} group cursor-pointer`}
                >
                  <div className="absolute inset-0 p-4 flex flex-col justify-between">
                    <h3 className="text-xl font-bold text-white">{category.name}</h3>
                    <div className="self-end transform rotate-45 translate-x-4 translate-y-4 opacity-80">
                      <div className="relative w-24 h-24">
                        <Image
                          src={category.image || "/placeholder.svg"}
                          alt={category.name}
                          fill
                          className="object-cover rounded shadow-lg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="absolute inset-0 bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              ))}
            </div>
          </section>
        </TabsContent>

        <TabsContent value="songs">
          <p className="text-muted-foreground text-center py-8">Search for songs to see results here</p>
        </TabsContent>

        <TabsContent value="artists">
          <p className="text-muted-foreground text-center py-8">Search for artists to see results here</p>
        </TabsContent>

        <TabsContent value="albums">
          <p className="text-muted-foreground text-center py-8">Search for albums to see results here</p>
        </TabsContent>

        <TabsContent value="playlists">
          <p className="text-muted-foreground text-center py-8">Search for playlists to see results here</p>
        </TabsContent>
      </Tabs>
    </div>
  )
}
