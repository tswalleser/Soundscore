"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function AuthErrorPage() {
  const searchParams = useSearchParams()
  const [errorMessage, setErrorMessage] = useState<string>("An authentication error occurred")
  const [errorType, setErrorType] = useState<string | null>(null)

  useEffect(() => {
    // Get error from URL query parameters
    const error = searchParams.get("error")

    if (error) {
      setErrorType(error)

      switch (error) {
        case "Configuration":
          setErrorMessage("There is a problem with the server configuration.")
          break
        case "AccessDenied":
          setErrorMessage("You do not have access to this resource.")
          break
        case "Verification":
          setErrorMessage("The verification link may have expired or already been used.")
          break
        case "CredentialsSignin":
          setErrorMessage("The email or password you entered is incorrect.")
          break
        case "Default":
          setErrorMessage("An authentication error occurred. Please try again.")
          break
        case "SessionRequired":
          setErrorMessage("You must be signed in to access this page.")
          break
        default:
          setErrorMessage(`Authentication error: ${error}`)
      }
    } else {
      // If no error parameter is provided, show a default message
      setErrorMessage("An unknown authentication error occurred. Please try again.")
    }
  }, [searchParams])

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-licorice to-dark-purple p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4 text-destructive">
            <AlertCircle size={48} />
          </div>
          <CardTitle className="text-2xl font-bold">Authentication Error</CardTitle>
          <CardDescription>There was a problem with your authentication</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert variant="destructive">
            <AlertDescription className="text-center py-2">{errorMessage}</AlertDescription>
          </Alert>

          {errorType && <div className="text-xs text-muted-foreground text-center">Error code: {errorType}</div>}
        </CardContent>
        <CardFooter className="flex justify-center gap-4">
          <Button variant="outline" asChild>
            <Link href="/login">Back to Login</Link>
          </Button>
          <Button asChild>
            <Link href="/">Go to Homepage</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
