"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { StarRating } from "@/components/star-rating"
import { supabase } from "@/lib/supabase"
import { useSession } from "next-auth/react"
import { useToast } from "@/hooks/use-toast"
import { Play, Heart, Clock, Music } from "lucide-react"
import type { Song, Artist, Album } from "@/lib/types"

export default function SongPage() {
  const { id } = useParams()
  const session = useSession()
  const { toast } = useToast()

  const [song, setSong] = useState<Song | null>(null)
  const [artist, setArtist] = useState<Artist | null>(null)
  const [album, setAlbum] = useState<Album | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [userRating, setUserRating] = useState(0)
  const [isLiked, setIsLiked] = useState(false)

  useEffect(() => {
    const fetchSongDetails = async () => {
      try {
        // Fetch song details
        const { data: songData, error: songError } = await supabase.from("songs").select("*").eq("id", id).single()

        if (songError) throw songError
        if (!songData) throw new Error("Song not found")

        setSong(songData)

        // Fetch artist details
        const { data: artistData, error: artistError } = await supabase
          .from("artists")
          .select("*")
          .eq("id", songData.artist_id)
          .single()

        if (artistError) throw artistError
        setArtist(artistData)

        // Fetch album details if available
        if (songData.album_id) {
          const { data: albumData, error: albumError } = await supabase
            .from("albums")
            .select("*")
            .eq("id", songData.album_id)
            .single()

          if (!albumError && albumData) {
            setAlbum(albumData)
          }
        }

        // Fetch user rating if logged in
        if (session.status === "authenticated" && session.data?.user?.id) {
          const { data: ratingData, error: ratingError } = await supabase
            .from("user_ratings")
            .select("rating")
            .eq("user_id", session.data.user.id)
            .eq("song_id", id)
            .single()

          if (!ratingError && ratingData) {
            setUserRating(ratingData.rating)
          }

          // Check if song is liked
          const { data: likeData, error: likeError } = await supabase
            .from("user_likes_songs")
            .select("id")
            .eq("user_id", session.data.user.id)
            .eq("song_id", id)
            .single()

          if (!likeError && likeData) {
            setIsLiked(true)
          }
        }
      } catch (error) {
        console.error("Error fetching song details:", error)
        toast({
          title: "Error",
          description: "Failed to load song details",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    if (id) {
      fetchSongDetails()
    }
  }, [id, session, toast])

  const handleRatingChange = async (rating: number) => {
    if (session.status !== "authenticated" || !session.data?.user?.id) {
      toast({
        title: "Authentication required",
        description: "Please sign in to rate songs",
        variant: "destructive",
      })
      return
    }

    try {
      // Check if rating already exists
      const { data: existingRating, error: checkError } = await supabase
        .from("user_ratings")
        .select("id")
        .eq("user_id", session.data.user.id)
        .eq("song_id", id)
        .single()

      if (checkError && checkError.code !== "PGRST116") {
        throw checkError
      }

      if (existingRating) {
        // Update existing rating
        const { error: updateError } = await supabase
          .from("user_ratings")
          .update({ rating, updated_at: new Date().toISOString() })
          .eq("id", existingRating.id)

        if (updateError) throw updateError
      } else {
        // Insert new rating
        const { error: insertError } = await supabase.from("user_ratings").insert([
          {
            user_id: session.data.user.id,
            song_id: id,
            rating,
          },
        ])

        if (insertError) throw insertError
      }

      setUserRating(rating)
      toast({
        title: "Rating updated",
        description: "Your rating has been saved",
      })
    } catch (error) {
      console.error("Error updating rating:", error)
      toast({
        title: "Error",
        description: "Failed to update rating",
        variant: "destructive",
      })
    }
  }

  const handleLikeToggle = async () => {
    if (session.status !== "authenticated" || !session.data?.user?.id) {
      toast({
        title: "Authentication required",
        description: "Please sign in to like songs",
        variant: "destructive",
      })
      return
    }

    try {
      if (isLiked) {
        // Remove like
        const { error } = await supabase
          .from("user_likes_songs")
          .delete()
          .eq("user_id", session.data.user.id)
          .eq("song_id", id)

        if (error) throw error
        setIsLiked(false)
        toast({
          title: "Removed from liked songs",
          description: "Song has been removed from your liked songs",
        })
      } else {
        // Add like
        const { error } = await supabase.from("user_likes_songs").insert([
          {
            user_id: session.data.user.id,
            song_id: id,
          },
        ])

        if (error) throw error
        setIsLiked(true)
        toast({
          title: "Added to liked songs",
          description: "Song has been added to your liked songs",
        })
      }
    } catch (error) {
      console.error("Error toggling like:", error)
      toast({
        title: "Error",
        description: "Failed to update liked status",
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!song || !artist) {
    return (
      <div className="text-center py-12">
        <h1 className="text-2xl font-bold">Song not found</h1>
        <p className="text-muted-foreground mt-2">The song you're looking for doesn't exist or has been removed.</p>
      </div>
    )
  }

  return (
    <div className="max-w-5xl mx-auto py-6">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="w-full md:w-1/3">
          {song.cover_url ? (
            <div className="relative aspect-square rounded-lg overflow-hidden">
              <Image src={song.cover_url || "/placeholder.svg"} alt={song.title} fill className="object-cover" />
            </div>
          ) : album?.cover_url ? (
            <div className="relative aspect-square rounded-lg overflow-hidden">
              <Image src={album.cover_url || "/placeholder.svg"} alt={album.title} fill className="object-cover" />
            </div>
          ) : (
            <div className="aspect-square rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <Music className="h-24 w-24 text-white" />
            </div>
          )}
        </div>

        <div className="flex-1">
          <div className="mb-4">
            <h1 className="text-3xl font-bold">{song.title}</h1>
            <p className="text-xl">{artist.name}</p>
            {album && (
              <p className="text-muted-foreground">
                From the album <span className="font-medium">{album.title}</span>
              </p>
            )}
          </div>

          <div className="flex gap-4 mb-6">
            <Button className="rounded-full px-6">
              <Play className="h-5 w-5 mr-2 ml-0.5" /> Play
            </Button>
            <Button variant={isLiked ? "default" : "outline"} className="rounded-full" onClick={handleLikeToggle}>
              <Heart className="h-5 w-5" fill={isLiked ? "currentColor" : "none"} />
            </Button>
          </div>

          <div className="mb-6">
            <p className="text-sm text-muted-foreground mb-1">Rate this song:</p>
            <StarRating rating={userRating} onRatingChange={handleRatingChange} size={28} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Duration</p>
                    <p className="text-lg">3:45</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Likes</p>
                    <p className="text-lg">1,245</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {song.file_url && (
            <div className="mt-6">
              <audio controls className="w-full" src={song.file_url}>
                Your browser does not support the audio element.
              </audio>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
